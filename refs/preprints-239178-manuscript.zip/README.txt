LaTeX source for the existing Trace-Torsion research follow-up candidate.
Title: Equivariant First-Jet Torsion Sources for an SU(2)/U(1) Director
Author: Chien-Chih Chen
Main file: main.tex
Bibliography: references.bib; main.bbl included for submission processors.
Build: latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
Requires an installed TeX distribution with the packages named in main.tex,
BibTeX and the standard amsplain bibliography style. No figures or data files.
Scientific text and bibliography copied byte-for-byte from the existing candidate.
This source ZIP is not evidence of platform acceptance or public submission.
